﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum TurbochargerType
    {
        SequentialTurbo,
        TwinTurbo
    }
}
